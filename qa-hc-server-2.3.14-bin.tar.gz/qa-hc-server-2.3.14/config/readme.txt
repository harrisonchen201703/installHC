HostController
==============

Requirements
------------
1. JRE 1.8 or above

Running HostController
----------------------
java -jar qa-hc-server-1.0.0.jar

There is also a script in the same folder called, starthc.sh which can be used for getting the latest,
hostcontroller from the build server and running it.  It is a Linux only script but could also be 
modified to work on Windows.

Another file also included is called getScripthc.sh which can be used to pull the starthc.sh from a 
webserver so that changes to the script can be picked up on the fly.

Keystore
--------
The keystore file has 2 RSA keys of size 1024 and 2048 to be used for testing purposes. The password for keystore is "Apple1995!". 
Use java system property -Djavax.net.ssl.trustStore to specify the keystore.

SSL logging
-----------
Use the java system property -Djavax.net.debug="ssl session" to log all SSL/TLS related messages
