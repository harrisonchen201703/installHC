# Host Controller
Host Controller Server (hc-server) is a collection of modules to do some special testing-related tasks on a host such as retreiving/uploading a file over HTTP, running a dummy server that echoes back UTF-8 bytes that it receives, etc. It is modular in design so that a vareity of functionality can be added as new requirements arise. 

## Features
### OS-agnostic host commands 
The HttpModule provides accessibility to the host machine by exposing several RESTful interfaces to do commonly used test steps.

<table>
 <tr>
  <td>/fs</td>
  <td>common operations on the host file system such as creating/deleting/renamaing a file, downloading a file from the web etc.</td>
 </tr>
 <tr>
  <td>/cli</td>
  <td>executable invocation on host via its Command Line Interpreter</td>
 </tr>
 <tr>
  <td>/dsa</td>
  <td>wraps around DSA's sendCommand and dsa_control tools</td>
 </tr>
 <tr>
  <td>/kernel/modules</td>
  <td>methods to load, unload, and list kernel modules</td>
 </tr>
</table>

Inter-module:
<table>
 <tr>
  <td>/messageChannel</td>
  <td>get messages from other modules</td>
 </tr>
</table>

The RESTful interfaces can be grouped based on their dependencies to the host OS. Some have implicit dependencies and other have explicit dependencies but generall they aim to provide OS-agnostic methods in order to support OS-agnostic test cases.

### Echo
The EchoModule is a simple server that echoes back the bytes it received in the request (sort of like ping) over both UDP and TCP. It is highly scalable and typically used for performance testing of FW/DPI modules in DSA.
EchoSSLModule provides the same functionality as EchoModule but over SSL. It is used for testing DPI module for SSL traffic.

### Syslog
The SyslogModule acts as a server to receive syslog messages in Common Event Format and Log Extended Event Format from DSA and DSA. The received messages can later be retrieved using the messageChannel resource in HttpModule

## Building

Both Maven and java 8 are required to hc-server.

Follow these steps to package hc-server:
<ol>
<li>cd dsaf2-hc-server</li>
<li>mvn clean dependency:copy-dependencies package</li>
</ol>

The artifacts as packaged in `dsaf2-hc-server/target/qa-hc-server-<version>.tar.gz`.

### Testing

There are 4 groups of tests based on the environment used to unit test: `kernel`, `native`, `unsupported-aix` and `none`. The `kernel` tests use kernel-space commands and may not work on certain environments like containers. The `native` tests use OS/shell-built-in commmands and therefore may not work on unsupported OSes. The `none` group of tests can run on any environment. The execution of these tests are selected using Maven profiles. There are 4 profiles as described below:

<table>
 <tr>
  <td>Profile name</td>
  <td>Activation (mvn test)</td>
  <td>Testgroup exclusion</td>
 </tr>
 <tr>
  <td>realdeal
  <td>-Denv=realdeal (or blank)</td>
  <td>none (i.e., all tests)</td>
 </tr>
 <tr>
  <td>docker</td>
  <td>-Denv=docker</td>
  <td>kernel</td>
 </tr>
 <tr>
  <td>unsupported</td>
  <td>-Denv=unsupported</td>
  <td>kernel, native</td>
 </tr>
  <tr>
  <td>realdeal-aix</td>
  <td>-Denv=aix</td>
  <td>kernel, unsupported-aix</td>
 </tr>
</table>

## Starting
You need Oracle/OpenJDK java 8.

Copy the hc-server package to a location and follow these steps:
  1. `tar -xf target/qa-hc-server-<version>-bin.tar.gz`
  2. `cd qa-hc-server-<version>`
  3. `java -jar qa-hc-server-<versionNumber>.jar`

You should these in hc-server.log
```
 ...
 INFO: Started listener bound to [0.0.0.0:9998]
 Aug 17, 2016 9:59:00 AM org.glassfish.grizzly.http.server.HttpServer start
 INFO: [RestServer] Started.
```

Note that if close the ssh/rdp session where you started hc-server, hc-server will stop. In unix you can run hc-server using nohup:
 `nohup  java -jar qa-hc-server-<versionNumber>.jar &`

You can check if hc-server is running using the netstat command (assuming 9998 is the default port for the restServer module):
 `netstat -anp | grep 9998`

## Stopping
If you are running hc-server in a ssh/rdp session, Ctrl+C will safely shutdown the server. If you are running it in the background using nohup, you will have to send SIGTERM to hc-server process:
 1. `ps -ef | grep java`
 2. note the pid
 3. `kill -SIGTERM <pid>`

## Logging
All hc-server logging go to hc-server.log.

Logback/slf4j library is used for all logging in DSAF, including hc-server. The config/logback.xml can be configured to change to log levels and to add/remove appenders. To change logging for all packages in hc-server from "trace" to "info"

```xml
<root level="info">
  <appender-ref ref="HCServer" />
</root>
```

## Configuring
hc-server can be customized at configuration time to add only some modules and not others. This is useful to prevent bloating HostController, loading buggy modules, etc.
hc-server uses the Spring framework for dependency injection of the modules and for their configuration. The config/hc-config.xml file defines modules as Spring beans and how they are wired together.

The basic hc-config.xml has the following definitions :

- property file location for the modules
- hostControllerModuleManager - its constructor takes an array of modules of type HostControllerModule which is an interface. So any class that implements this interface can be added.

Each module can have its own constructor arguments which must be passed through hc-config.xml. The values of the arguments can be either be hardcoded in the xml file or can be read from a properties. Note that the constructor arguments can any instance of a Java object wrapped as a Spring bean, i.e., they need be simple String arguments.

echoModule, echoSSLModule and restModule modules are configured by editing echoServer.properties, echoSSLServer.properties and restServer.properties respectively.

By default, the above three modules are loaded (and in future more modules) but hc-server can be customized easily by commenting out the modules you don't want. For example you may want to run only the http module.

Note: The Spring framework complements HostController, by allowing it to be customized at configuration time. However the HostController can be created and started programmatically without requiring the Spring dependency.

## Default module ports:
| Module        | Port       |
| ------------- |:-------------:|
| HttpModule    | 9998 |
| EchoModule (TCP) | 9090 |
| EchoModule (UDP) | 9091 |
| EchoSSLModule | 1443      |
| SyslogModule | 9094      |

## Distribution
HostController and its modules are compiled, versioned, packaged and distributed through a S3 bucket:
s3://ds-devbuilds/jenkins-AutomationTesting-Build_Host_Controller-2/

Older versions are available in our maven repository: 
http://10.203.154.89:8081/artifactory/ext-release-local/com/trendmicro/qa/qa-hc-server/ 

You can either get a zip file or a tarball containing hc-server jar and all its dependencies, or just the hc-server.jar.

## How to use CURL against REST interface
In order to use REST interface, we can use a standard *nix command line utility called `curl`. To invoke a particular method we need to know the URL for the call and the list of parameters required.

### Sample REST calls
| URL | Method | Command | Output |
| --- | ------ | ------- | ------ |
| /fs/file/move | POST | curl -X POST 'http://10.203.158.179/fs/file/move?srcFileLoc=README.md&dstFileLoc=../readme.md' | {"processReturnCode":0,"processOutput":"\n 1 file(s) moved.","throwable":null} |
| /fs/file/copy | POST | curl -X POST 'http://10.203.158.179/fs/file/copy?srcFileLoc=readme.txt&dstFileLoc=README-AGAIN.txt' | {"processReturnCode":0,"processOutput":"\n 1 file(s) copied.","throwable":null} |
| /fs/file/rename | POST | curl -X POST 'http://10.203.158.179/fs/file/rename?srcFileLoc=README-AGAIN.txt&dstFileLoc=DO-NOT-README.txt' | {"processReturnCode":0,"processOutput":"","throwable":null} |
| /fs/file/delete | DELETE | curl -X DELETE 'http://10.203.158.179/fs/file/delete?fileLoc=DO-NOT-README.txt' | {"processReturnCode":0,"processOutput":"","throwable":null} |
| /fs/file/setexecbin | POST | curl -X POST 'http://10.203.158.179/fs/file/setexecbit?fileLoc=readme.txt' | No executable name for key=(WINDOWS, SET_FILE_EXEC_BIT) |
| /fs/dir/list | GET | curl -X GET 'http://10.203.158.179/fs/dir/list?dirLoc=config' | {"processReturnCode":0,"processOutput":"\n Volume in drive C has no label.\n Volume Serial Number is EAD3-5C9B\n\n Directory of C:\\Dropzone\\qa-hc-server-2.1.4\\config\n\n05/04/2017 12:24 PM <DIR> .\n05/04/2017 12:24 PM <DIR> ..\n03/03/2017 08:27 AM 558 echoServerTCP.properties\n03/03/2017  08:27 AM 558 echoServerUDP.properties\n03/03/2017  08:27 AM 512 echoSSLServer.properties\n05/02/2017  02:31 PM 3,551 hc-config.xml\n03/03/2017  08:27 AM 144 iau.xml\n03/03/2017 08:27 AM 691 logback.xml\n05/04/2017  12:25 PM 845 restServer.properties\n 7 File(s) 6,859 bytes\n 2 Dir(s)  21,728,686,080 bytes free","throwable":null} |
| /fs/dir/create | POST | curl -X POST 'http://10.203.158.179/fs/dir/create?dirLoc=auto-test' | {"processReturnCode":0,"processOutput":"","throwable":null} |
| /fs/dir/delete | DELETE | curl -X DELETE 'http://10.203.158.179/fs/dir/delete?dirLoc=auto-test' | {"processReturnCode":0,"processOutput":"","throwable":null} |
| /fs/file/grep | GET | curl -X GET 'http://10.203.158.179/fs/file/grep?fileLoc=ac-works.bat&regex=hello' | {"processReturnCode":0,"processOutput":"\n12:31:44.059 [RestServer-worker(1)] DEBUG ExecutableInvoker - Got a request to run [[findstr.exe, hello, ac-works.bat]]\n12:31:44.084 [RestServer-worker(1)] TRACE com.trendmicro.qa.hc.proc.ProcessExecutor - Starting a task to read the output for process=[[\"findstr.exe\",\"hello\",\"ac-works.bat\"]]\n12:31:44.084 [RestServer-worker(1)] TRACE com.trendmicro.qa.hc.proc.ProcessExecutor - Starting a task to wait for process=[[\"findstr.exe\",\"hello\",\"ac-works.bat\"]] to finish\n12:32:08.584 [RestServer-worker(1)] DEBUG ExecutableInvoker - Got a request to run [[findstr.exe, hello, hc-server.log]]\n12:32:08.587 [RestServer-worker(1)] TRACE com.trendmicro.qa.hc.proc.ProcessExecutor - Starting a task to read the output for process=[[\"findstr.exe\",\"hello\",\"hc-server.log\"]]\n12:32:08.587 [RestServer-worker(1)] TRACE com.trendmicro.qa.hc.proc.ProcessExecutor - Starting a task to wait for process=[[\"findstr.exe\",\"hello\",\"hc-server.log\"]] to finish","throwable":null} |
| /fs/file/tail | GET | curl -X GET 'http://10.203.158.179/fs/file/tail?fileLoc=./hc-server.log&numLines=1' | {"processReturnCode":0,"processOutput":"\n12:33:11.675 [ProcessExecutor-5] INFO  com.trendmicro.qa.hc.proc.ProcessRunWaiter - Will wait for a max time=600 seconds for process=java.lang.ProcessImpl@429cb5ff","throwable":null} |
| /fs/file/install | POST | curl -X POST 'http://10.203.158.179/fs/file/install?softwareName=https://github.com/snakefoot/snaketail-net/releases/download/1.9.4/SnakeTail.v1.9.4.x64.msi' | {"processReturnCode":0,"processOutput":"","throwable":null} |
| /fs/web/get | POST | curl -X POST 'http://10.203.158.179/fs/web/get?url=https://github.com/snakefoot/snaketail-net/releases/download/1.9.4/SnakeTail.v1.9.4.x64.msi&destFileLoc=SnakeTail.v1.9.4.x64.msi' | "OK" |
| /fs/file | GET | curl -X GET 'http://10.203.158.179/fs/file?fileLocation=testfile.txt' | Sample test content. |
| /fs/file | POST | curl -i -X POST -H 'Content-Type: multipart/form-data' -F file=@HostControllerModule.class 'http://10.203.158.179/fs/file' | C:\Dropzone\qa-hc-server-2.1.4\HostControllerModule.class |
| /fs/file/exists | GET | curl -X GET 'http://10.203.158.179/fs/file/exists?filePath=&fileName=HostControllerModule.class' | true |
| /kernel/module/all | GET | curl -X GET 'http://10.203.158.179/kernel/module/all' | {"processReturnCode":0,"processOutput":"\n\nFilter Name                     Num Instances    Altitude    Frame\n------------------------------  -------------  ------------  -----\nvsepflt                                 3       328200         0\nluafv                                   1       135000         0\nFileInfo                                3        45000         0","throwable":null} |
| /kernel/module/<MODULE_NAME> | GET | curl -X GET 'http://10.203.158.179/kernel/module/FileInfo' | {"processReturnCode":0,"processOutput":"\n\nSERVICE_NAME: FileInfo \n        TYPE               : 2  FILE_SYSTEM_DRIVER  \n        STATE              : 4  RUNNING \n                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)\n        WIN32_EXIT_CODE    : 0  (0x0)\n        SERVICE_EXIT_CODE  : 0  (0x0)\n        CHECKPOINT         : 0x0\n        WAIT_HINT          : 0x0","throwable":null} |
| /kernel/module/stop | POST | curl -X POST 'http://10.203.158.179/kernel/module/stop?moduleName=FileInfo' | {"processReturnCode":1,"processOutput":"\n\nUnload failed with error: 0x80070032\nThe request is not supported.","throwable":null} |
| /kernel/module/start | POST | curl -X POST 'http://10.203.158.179/kernel/module/start?moduleName=FileInfo' | {"processReturnCode":1,"processOutput":"\n\nLoad failed with error: 0x80070420\nAn instance of the service is already running.","throwable":null} |
| /cli/invoke | POST | curl -i -X POST -H 'Content-type: application/json' -d '{"commandAndArgs":["cmd.exe", "/c", "ver"]}' 'http://ec2-34-209-238-252.us-west-2.compute.amazonaws.com/cli/invoke' | {"processReturnCode":0,"processOutput":"\n\nMicrosoft Windows [Version 6.3.9600]","throwable":null} |
| /dsa/trace | GET | curl -X GET http://ec2-34-223-249-178.us-west-2.compute.amazonaws.com/dsa/trace | {"processReturnCode":0,"processOutput":"\nHTTP Status: 200 - OK\nResponse:\nTrace settings are currently: dsp.ac.drift,dsp.ac.block,RecordFsEvents","throwable":null} |
| /dsa/trace | POST | curl -X POST 'http://ec2-34-223-249-178.us-west-2.compute.amazonaws.com/dsa/trace?traceSettings=dsp.ac.drift,dsp.ac.block,RecordFsEvents' | {"processReturnCode":0,"processOutput":"\nHTTP Status: 200 - OK\nResponse:\nTrace settings are currently: dsp.ac.drift,dsp.ac.block,RecordFsEvents","throwable":null} |

## Internals
### A case for Spring
Some of the goals for hc-server are:
- extensibility (should accomodate various testing tasks)
- usability (should be simple to use)
- portability (across various platforms that DS supports)
- relaibility

These principles are common to many other types of software - so common that there are many design patterns to follow and antipatterns to avoid. If this is so common then aren't existing tools and frameworks that we could use? Yes - Spring Framework:

"A Java application is a loose term that runs the gamut from constrained, embedded applications to n-tier, server-side enterprise applications typically consisting of objects that collaborate to form the application proper. Thus the objects in an application have dependencies on each other.

Although the Java platform provides a wealth of application development functionality, it lacks the means to organize the basic building blocks into a coherent whole, leaving that task to architects and developers. Although you can use design patterns such as Factory, Abstract Factory, Builder, Decorator, and Service Locator to compose the various classes and object instances that make up an application, these patterns are simply that: best practices given a name, with a description of what the pattern does, where to apply it, the problems it addresses, and so forth. Patterns are formalized best practices that you must implement yourself in your application.

The Spring Framework Inversion of Control (IoC) component addresses this concern by providing a formalized means of composing disparate components into a fully working application ready for use. The Spring Framework codifies formalized design patterns as first-class objects that you can integrate into your own application(s). Numerous organizations and institutions use the Spring Framework in this manner to engineer robust, maintainable applications." [http://docs.spring.io/spring/docs/5.0.0.M1/spring-framework-reference/htmlsingle/]

Naturally Spring framework seemed to be a fit for hc-server. But like any other design choices it isn't void of criticisms. One common one is the use of xml to configure hc-server. For some it is hard to read and use. But despite all the backlash for xml it is a rich language for modeling. The hc-server configuration using xml effectively communicates its modular design, types and values for the modules. For e.g., consider the following configuration:

```xml
<bean id="modules" name="modules" class="com.trendmicro.qa.hc.HostControllerModuleManager">
 <constructor-arg>
  <array>
   <bean id="module1" class="Module1"/>
   <bean id="module2" class="Module2"/>
  </array>
 </constructor-arg>
</bean>
```
The above configuration exposes the nested object module of the HostControllerModuleManager, which takes an array of HostControllerModule objects. In this case we are passing instances of Module1 and Module2.

This expressive nature of the hc-server configuration allows you to configure not only which modules you want to load but also you the modules themselves are configured. 

For example, the HttpModule module has 5 constructor arguments:
- port to listen on
- number of kernel threads (artifact of the underlying grizzly framework)
- number of worker threads (artifact of the underlying grizzly framework)
- thread pool to use for the sampler/profile rest resource
- process executor to use for the process executor rest resource (process executor is a standalone utility class to run processes)

These arguments are building blocks for the RestServer and this fact is fully exposed via the configuration:

```xml
<bean id="restServer" name="restServer" class="com.trendmicro.qa.hostcontroller.rest.RESTServer">
 <constructor-arg name="port" value="${restServer.port}"></constructor-arg>
 <constructor-arg name="numKernelThreads" value="${restServer.kernelThreadPoolSize}"> </constructor-arg>
 <constructor-arg name="numWorkerThreads" value="${restServer.workerThreadPoolSize}"></constructor-arg>
 <constructor-arg name="samplerThreadPool">
  <bean class="com.trendmicro.qa.hostcontroller.SamplerThreadPool">
   <constructor-arg value="${restServer.samplerThreadPoolSize}" />
  </bean>
 </constructor-arg>
 <constructor-arg name="processExecutor"><bean class="com.trendmicro.qa.util.proc.ProcessExecutor" /></constructor-arg>
</bean>
```

In other words, the dependency between the building blocks are exposed and it can be edited to customize each building block without recompiling the program.

### Scalability
HostController is built on top of a lightweight but a reliable server framework called Grizzly. The Echo* modules have been used for testing edge conditions in DSA for maximum connection limits, with thousands of threads.

### Implicit vs explicit dependencies on host OS
Deep Security tests can be OS/platform specific or OS/platform-agnostic. A platform-agnostic test must be able to run against multiple platforms with minimal source code change. A platform-specific test must be to run against its supported platform. Therefore an abstraction layer is needed to translate test steps to OS commands for platform specific tests. 

The abstraction layer is called the ExecutableLabelMap that is a collection of map functions:
<p>
(platform, executableLabel) -> executableName
</p>
For example: 
<ul>
<li>(WINDOWS, KERNELMODCONTROLLIST) ->  fltMC.exe</li>
<li>(AMAZON_LINUX, KERNELMODCONTROLLIST) -> modprobe</li>
</ul>

The ExecutableLabelMap fits in between the ProcessExecutor and the rest resources as depicted below:

![alt text](https://dsgithub.trendmicro.com/deep-security/dsaf2-hc-server/blob/261e5f07e93d28fe7ae4b0ad1b28d6f0680225a4/docs/onion-process-exec.jpg?raw=true)

Also, please don't forget to update the mapping on dsaf2-hc-client, if you are adding a new platform.

#### Process creation in Unix (shell vs exec)
The ProcessBuilder.start() creates a native process but when translating a high level test step to actual parameters, the command can be either passed through shell which in turn interprets the command and invokes a system call, or directly invoke an executable that invokes a system call. For example, `cd` command is a built-in shell command on Ubuntu but there is no executable called `cd`. For some use cases it may be desirable to use shell, while for others it may be desirable to directly invoke the executable.

